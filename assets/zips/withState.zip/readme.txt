TSGK World icons flag pack, free for any use.
Bordered version 18 x 12.
Borderless version 16 x 10.

+ Complete cctld icons flags pack up-to-date by TSGK based from an uncomplete and partialy obsolete icons flags pack from an unknow author.
Using ISO 3166-1 alpha-2 as standar.
+ Complete [US] U.S. states + district of columbia icons flags pack up-to-date by TSGK.
+ Complete [CA] Canadian states and territories icons flags pack up-to-date by TSGK.
+ Complete [AU] Australian states and territories icons flags pack up-to-date by TSGK.
+ Complete [DE] German states and territories icons flags pack up-to-date by TSGK.
+ Complete [AT] Austrian states and territories icons flags pack up-to-date by TSGK.
+ Complete [IT] Italian states and territories icons flags pack up-to-date by TSGK.
+ Complete [ES] Spanish states and territories icons flags pack up-to-date by TSGK.
+ Complete [BE] Belgian states and territories icons flags pack up-to-date by TSGK.
+ Complete [NL] Dutch states and territories icons flags pack up-to-date by TSGK.
+ Complete [BR] Brazilian states and territories icons flags pack up-to-date by TSGK.
+ Complete [AR] Argentine states and territories icons flags pack up-to-date by TSGK.
+ Complete [AE] Emirati states and territories icons flags pack up-to-date by TSGK.
+ Complete [KM] Comoran states and territories icons flags pack up-to-date by TSGK.
+ Complete [FM] Micronesian states and territories icons flags pack up-to-date by TSGK.
+ Complete [PL] Polish states and territories icons flags pack up-to-date by TSGK.
+ Complete [BQ] Bonaire, Sint Eustatius and Saba states and territories icons flags pack up-to-date by TSGK.
+ Complete [EC] Ecuadorian states and territories icons flags pack up-to-date by TSGK.
+ Complete [CL] Chilian states and territories icons flags pack up-to-date by TSGK.
+ Complete [BO] Bolivian states and territories icons flags pack up-to-date by TSGK.
+ Complete [UY] Uruguayan states and territories icons flags pack up-to-date by TSGK.
+ Complete [PY] Paraguayan states and territories icons flags pack up-to-date by TSGK.
+ Complete [FR] French states and territories icons flags pack up-to-date by TSGK.
+ Complete [PF] French Polynesian states and territories icons flags pack up-to-date by TSGK.
+ Complete [UM] U.S Minor Outlying Islands states and territories icons flags pack up-to-date by TSGK.
+ Complete [RU] Russian states and territories icons flags pack up-to-date by TSGK.
+ Complete [CO] Colombian states and territories icons flags pack up-to-date by TSGK.
+ Complete [MX] Mexican states and territories icons flags pack up-to-date by TSGK.
+ Complete [VE] Venezuelan states and territories icons flags pack up-to-date by TSGK.
+ Complete [CR] Tico states and territories icons flags pack up-to-date by TSGK.
+ Complete [JP] Japanese states and territories icons flags pack up-to-date by TSGK.
+ Complete [GG] Guernsey states and territories icons flags pack up-to-date by TSGK.
+ Complete [CH] Swiss states and territories icons flags pack up-to-date by TSGK.
+ Complete [MY] Malaysian states and territories icons flags pack up-to-date by TSGK.
+ Complete [FI] Finns states and territories icons flags pack up-to-date by TSGK.
+ Complete [SE] Swedish states and territories icons flags pack up-to-date by TSGK.
+ Complete [NO] Norwegian states and territories icons flags pack up-to-date by TSGK.
+ Complete [UA] Ukrainian states and territories icons flags pack up-to-date by TSGK.
+ Complete [EE] Estonian states and territories icons flags pack up-to-date by TSGK.
+ Complete [LT] Lithuanian states and territories icons flags pack up-to-date by TSGK.
+ Complete [BY] Belarusian states and territories icons flags pack up-to-date by TSGK.
+ Complete [SK] Slovak states and territories icons flags pack up-to-date by TSGK.
+ Complete [CZ] Czech states and territories icons flags pack up-to-date by TSGK.
+ Complete [HR] Croatian states and territories icons flags pack up-to-date by TSGK.
+ Complete [DK] Danish states and territories icons flags pack up-to-date by TSGK.
+ Complete [LI] Liechtenstein states and territories icons flags pack up-to-date by TSGK.
+ Complete [PK] Pakistani states and territories icons flags pack up-to-date by TSGK.
+ Complete [JE] Jersey states and territories icons flags pack up-to-date by TSGK.
+ Complete [WF] Wallisian & Futunan states and territories icons flags pack up-to-date by TSGK.
+ Complete [AD] Andorran states and territories icons flags pack up-to-date by TSGK.
+ Complete [BH] Bahraini states and territories icons flags pack up-to-date by TSGK.
+ Complete [PE] Peruvian states and territories icons flags pack up-to-date by TSGK.
+ Complete [SV] Salvadoran states and territories icons flags pack up-to-date by TSGK.
+ Complete [NI] Nicaraguan states and territories icons flags pack up-to-date by TSGK.
+ Complete [GT] Guatemalan states and territories icons flags pack up-to-date by TSGK.
+ Complete [BA] Bosnians & Herzegovinians states and territories icons flags pack up-to-date by TSGK.
+ Complete [ET] Ethiopian states and territories icons flags pack up-to-date by TSGK.
+ Complete [SS] South Sudanese states and territories icons flags pack up-to-date by TSGK.
+ Complete [ID] Indonesian states and territories icons flags pack up-to-date by TSGK.
+ Complete [EG] Egyptian states and territories icons flags pack up-to-date by TSGK.
+ Complete [LR] Liberian states and territories icons flags pack up-to-date by TSGK.
+ Complete [MM] Burmese states and territories icons flags pack up-to-date by TSGK.
+ Complete [GL] Greenlander states and territories icons flags pack up-to-date by TSGK.
+ Complete [HU] Hungarian states and territories icons flags pack up-to-date by TSGK.
+ Complete [MN] Mongolian states and territories icons flags pack up-to-date by TSGK.
+ Complete [PW] Palauan states and territories icons flags pack up-to-date by TSGK.
+ Complete [TW] Taiwanese states and territories icons flags pack up-to-date by TSGK.
+ Complete [KR] South Korean states and territories icons flags pack up-to-date by TSGK.
+ Complete [SB] Solomon Islander states and territories icons flags pack up-to-date by TSGK.
+ Complete [LK] Sri Lankan states and territories icons flags pack up-to-date by TSGK.
+ Complete [SM] Sammarinese states and territories icons flags pack up-to-date by TSGK.
+ Complete [RE] R�union Islander states and territories icons flags pack up-to-date by TSGK.
+ Complete [VU] Vanuatuan states and territories icons flags pack up-to-date by TSGK.
+ Complete [PA] Panamanian states and territories icons flags pack up-to-date by TSGK.
+ Complete [PG] Papua New Guinean states and territories icons flags pack up-to-date by TSGK.
+ Complete [IN] Indian states and territories icons flags pack up-to-date by TSGK.
+ Complete [MT] Maltese states and territories icons flags pack up-to-date by TSGK.
+ Complete [TH] Thai states and territories icons flags pack up-to-date by TSGK.
+ Complete [MK] Macedonian states and territories icons flags pack up-to-date by TSGK.
+ Complete [PR] Puerto Rican states and territories icons flags pack up-to-date by TSGK.
+ Complete [PH] Filipino states and territories icons flags pack up-to-date by TSGK.
+ Partial [IE] Irish states and territories icons flags pack up-to-date by TSGK.
+ Partial [UK] British states and territories icons flags pack up-to-date by TSGK.
+ Partial [AG] Antiguan & Barbudan states and territories icons flags pack up-to-date by TSGK.
+ Partial [AL] Albanian states and territories icons flags pack up-to-date by TSGK.
+ Partial [ST] Santomean states and territories icons flags pack up-to-date by TSGK.
+ Partial [PT] Portuguese states and territories icons flags pack up-to-date by TSGK.
+ Partial [RO] Romanian states and territories icons flags pack up-to-date by TSGK.
+ Partial [KG] Kyrgyz states and territories icons flags pack up-to-date by TSGK.
+ Partial [SR] Surinamese states and territories icons flags pack up-to-date by TSGK.
+ Partial [ME] Montenegrin states and territories icons flags pack up-to-date by TSGK.
+ Partial [CN] Chinese states and territories icons flags pack up-to-date by TSGK.
+ Partial [RS] Serbian states and territories icons flags pack up-to-date by TSGK.
+ Partial [NZ] New Zealander states and territories icons flags pack up-to-date by TSGK.
+ De facto states icons flags pack up-to-date by TSGK.

+ Miscellaneous icons flags pack by TSGK
-- Organisations
-- Linguistics
-- Jolly rogers
-- Religious
-- Micronations
-- Sexual identities

This icons flags pack can be downloaded at:
http://forum.tsgk.com/viewtopic.php?t=4921

Total flags: 2144

Last modified September 2, 2017.
v1.6.4