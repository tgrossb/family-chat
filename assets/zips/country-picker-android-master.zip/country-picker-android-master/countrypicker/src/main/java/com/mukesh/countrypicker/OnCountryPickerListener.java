package com.mukesh.countrypicker;

public interface OnCountryPickerListener {
  void onSelectCountry(Country country);
}
