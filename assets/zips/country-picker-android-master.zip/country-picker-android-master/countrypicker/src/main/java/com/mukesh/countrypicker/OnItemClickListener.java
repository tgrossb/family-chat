package com.mukesh.countrypicker;

public interface OnItemClickListener {
  void onItemClicked(Country country);
}